package commdgriest.httpsgithub.wimk;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/*
    Displays basic information about the app
*/

public class AboutScreen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_screen);
    }
}
