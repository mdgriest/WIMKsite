package commdgriest.httpsgithub.wimk;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/*
    Credit screen for icons acquired through The Noun Project
*/

public class NounProjCreditScreen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noun_proj_credit_screen);
    }
}
